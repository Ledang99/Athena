Project Athena Android 0.7.0 (debug)

Install:
  adb install -r project-athena-v0.7.0-debug.apk

What's new in 0.7.0 (Phase A: Book Dossier & Visual Summaries):
- Dedicated Book Dossier / study view: tap any cover tile to open
- Mind Maps & Visual Summaries: attach Pinterest/web infographics, framework slides, or summary graphics
- Full-screen pinch-to-zoom & pan viewer for reading mind maps on phone
- Per-book notes: write key takeaways, ideas, and quotes attached to a specific ebook
- Delete individual summary images and notes
- Change reading status directly from the dossier view
- Easy access to "Open reader" or "Edit details"

Workflow:
1. Tap any book cover on your shelf to enter its Dossier.
2. Under "Mind Maps & Visual Summaries", tap "+ Add Image" and pick an infographic saved from Pinterest or the web.
3. Tap the image thumbnail anytime to pinch-zoom into the mind map.
4. Jot down your personal notes & takeaways right below.
