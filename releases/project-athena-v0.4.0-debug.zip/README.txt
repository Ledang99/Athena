Project Athena Android 0.4.0 (debug)

Install:
  adb install -r project-athena-v0.4.0-debug.apk

Or copy the APK to your phone and open it (allow install from this source).

What's new in 0.4.0:
- Preferred ebook viewer is a compact Settings dropdown
- Library totals (ebooks / PDF / EPUB) come from the catalog database
- Duplicates show copy count and folder for each copy
- Exact duplicates match SHA-256; likely matches share title, size, and type

Notes:
- This is a debug build for testing
- Grant folder access via the system picker (Downloads subfolders work best)
