Project Athena Android 0.6.0 (debug)

Install:
  adb install -r project-athena-v0.6.0-debug.apk

What's new in 0.6.0:
- Moon+-style shelf: compact black top liner, covers first
- Tiles view by default; switch to Details from ⋮
- Multi-folder libraries: Add folder / Rescan all / Remove folder
- Section dropdown: All Books, Unread/Reading/Finished, folders, collections
- Search and Filter/Sort from the top bar
- Downloads tip card and bulky library chrome removed

Tips:
- ≡ menu: add folder, import files, rescan, remove folders
- All Books ▾: switch sections
- Per-cover ⋮: open, edit, set reading status
