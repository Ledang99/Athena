Project Athena Android 0.5.0 (debug)

Install:
  adb install -r project-athena-v0.5.0-debug.apk

What's new in 0.5.0:
- Category tags captured from PDF/EPUB metadata, editable manually
- Standard collections (Habits, Investing, Productivity, and more)
- Reading status: Unread / Reading / Finished
- Sort by title, recently opened, recently added, or status
- Assign notes to the same collection catalogue

Notes:
- Rescan once to backfill tags/collections on existing books
- Manual tag and collection edits are kept across rescans
- Opening an unread book marks it as Reading
